Esta tarea se compone de los metodos Brendt, Interpolacion, Newton-Raphson, Biseccion y Secante. A la hora de correr la tarea se debe de hacer lo siguiente:
    1. Se debe de posicionar en la carpeta >> include para ver todo el codigo de los 
       metodos.
    2. Para hacer las pruebas unitarias se debera de ir a la carpeta >> test y luego 
       correr el archivo que se llama >> testRootFinders.cpp 
    3. En esta tarea no se ejecutaron los benchmark ni se hicieron las graficacion de
       las funciones asi que no se incluyeron en este.
    4. Ademas de que el grupo es de 3 integrantes pero solo trabajaron Ronny Quesada y 
       Esteban Herrera.   
